# Lamborghini scroll site

Static site, no build step. Deploy the folder as-is.

- Vercel: `vercel --prod` in this folder (vercel.json sets long cache headers)
- Netlify: drag the folder into Netlify Drop, or connect the repo (netlify.toml included)

Edit points (all in app.js):
- `S` array: the 10 story sections (frame range `a`, accent colour `c`, headline, callouts, copy).
  Callout `x`,`y` = dot position in % of the screen, `dx`,`dy` = stick offset in px, `hl` = stick length.
- `CARS`, `FIN`, `WH`, `INT`: collection and configurator options.
- `CONTACT_EMAIL`: fallback address for the form (used when the host has no form handler, e.g. Vercel).
  On Netlify the form is captured automatically (data-netlify). Replace the placeholder email/phone in index.html.

Frames stay in /frames as frame_000000.webp ... frame_000547.webp (unchanged).

## Changes in this version
- Phones now get a 9:16 crop of the frames that follows the callout (no letterbox). Desktop unchanged.
- Particles only on the big chapter titles (`HEAD_PARTICLES` in app.js). Small texts are plain.
- Configurator: `img/v/<car>-<finish>.webp` (24 recoloured photos) + generated wheel and interior drawings.
- Page wipe transition between Story / Choose your bull / Contact, plus the 01/02/03 pager.
- Frames recompressed (webp q72) so the whole site is about 23.5 MiB.
