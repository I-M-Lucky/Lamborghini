/* =====================================================================
   LAMBORGHINI SCROLL SITE : app.js  (all the behaviour lives in this file)

   Before you start judging: I didn't use AI to code this. I only used it
   to write the comments so you can understand the code easily, hehe.

   MAP OF THIS FILE
   1. Config ........ contact email, frame count, story sections (S)
   2. Layers ........ builds the text/callout layers for every story section
   3. Page wipe ..... the pagination transition between Story / Choose your bull / Contact
   4. Frame loader .. loads the 548 .webp frames and draws them on the canvas
   5. Particle text . the particle effect (ONLY used on the big section titles)
   6. Scroll engine . maps scroll position -> section + frame
   7. Configurator .. "Choose your bull" (cars, finishes, wheels, interior)
   8. Contact form .. send the build by form POST or e-mail
   ===================================================================== */
(() => {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  /* ---------- 1. CONFIG ---------- */
  /* CONTACT: CHANGE THIS to your real e-mail.
     If the form can't be posted (e.g. on Vercel), the site opens the visitor's mail app
     addressed to this address. Also change the visible e-mail / phone / showroom in index.html
     (look for "EDIT YOUR CONTACT INFO HERE"). */
  const CONTACT_EMAIL = "hello@yourdomain.com";
  // N = number of frames in /frames, FR(i) = path of frame i (frame_000000.webp ...)
  const N = 548, FR = i => `frames/frame_${String(i).padStart(6, "0")}.webp`;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  // visitors who asked their OS for "reduced motion" get no particles (plain text instead)
  if (reduce) document.documentElement.classList.add("nofx");
  /* PARTICLE SWITCHES. The particle effect is used on ONE text only: the bottom primary title of each chapter
     (Ignition, Stance, Profile...). Everything else is plain text, including the big headline (LAMBORGHINI, PLANTED...).
     TITLE_PARTICLES = false turns the effect off completely. HEAD_PARTICLES = true would put it back on the big headline. */
  const TITLE_PARTICLES = true, TITLE_FX = TITLE_PARTICLES && !reduce;
  const HEAD_PARTICLES = false, HEAD_FX = HEAD_PARTICLES && !reduce;
  const AR = 16 / 9;                // aspect ratio of the frames (1920x1080)

  /* ---------- story config: a = frame range, c = accent, hp = headline placement ---------- */
  const S = [
    {
      n: "Ignition", a: [0, 28], c: "#FFE08A", h: "LAMBORGHINI", hp: { al: "c", y: 11 },
      t: "Ignition", d: "Two blades of light slice the dark. Before a wheel turns, the bull has already spoken.",
      co: [{ x: 27, y: 50, dx: 70, dy: -95, hl: 250, l: "Y-shaped light signature", b: "Hexagon-cored LEDs that say Lamborghini from a block away." },
      { x: 66, y: 45, dx: 60, dy: -45, hl: 230, l: "One wedge, nose to tail", b: "A silhouette drawn with a ruler and a grudge." }]
    },
    {
      n: "Stance", a: [29, 76], c: "#FFC400", h: "PLANTED", hp: { al: "l", x: 5, y: 13 },
      t: "Stance", d: "Forged wheels, carbon-ceramic brakes and a body that hugs the road like it owes it something.",
      co: [{ x: 47, y: 73, dx: 80, dy: -70, hl: 250, l: "Carbon-ceramic brakes", b: "Yellow calipers. Fade-free stopping from speeds you will not mention to your insurer." },
      { x: 54, y: 31, dx: 90, dy: -45, hl: 220, l: "Barely over a metre tall", b: "The cabin is a cockpit and the roof is an afterthought." }]
    },
    {
      n: "Profile", a: [77, 114], c: "#B9CC7A", h: "SHAPED BY WIND", hp: { al: "r", x: 5, y: 15 },
      t: "Profile", d: "Every scoop and blade has a job. Air is pushed, pulled and persuaded down onto the tarmac.",
      co: [{ x: 60, y: 54, dx: -70, dy: 100, hl: 250, l: "Side air intakes", b: "They feed the V12 and cool the brakes, cut like facets in a gemstone." },
      { x: 90, y: 34, dx: -70, dy: 48, hl: 210, l: "Active rear wing", b: "Trimmed in milliseconds for grip or for less drag." }]
    },
    {
      n: "Signature", a: [115, 168], c: "#FF3B4E", h: "HEXAGON FIRE", hp: { al: "c", y: 8 },
      t: "Signature", d: "Six hexagons glow red in the haze. In a rear-view mirror, they are the last thing anyone sees.",
      co: [{ x: 52, y: 46, dx: -90, dy: -100, hl: 250, l: "Hexagonal tail lights", b: "The brand's geometry, burned into every rear lamp." },
      { x: 63, y: 70, dx: 90, dy: 60, hl: 240, l: "Race-bred diffuser", b: "Carbon fins pull air out from under the car and press it into the road." }]
    },
    {
      n: "Metamorphosis", a: [169, 222], c: "#C7D66D", h: "OUT OF THE SMOKE", hp: { al: "l", x: 6, y: 16 },
      t: "Metamorphosis", d: "The haze lifts and a matte green body emerges, bronze wheels catching the first real light.",
      co: [{ x: 60, y: 56, dx: 90, dy: -95, hl: 240, l: "Satin green finish", b: "A matte surface with the depth of old forest." },
      { x: 74, y: 68, dx: 60, dy: 75, hl: 240, l: "Bronze forged wheels", b: "Light, heat-treated and impossible to ignore." }]
    },
    {
      n: "Anatomy", a: [223, 300], c: "#E39A4B", h: "INSIDE THE BULL", hp: { al: "r", x: 5, y: 12 },
      t: "Anatomy", d: "Doors open, panels lift and the machinery shows itself: suspension, carbon tub and engine, all on display.",
      co: [{ x: 50, y: 55, dx: -90, dy: -120, hl: 250, l: "Pushrod suspension", b: "Horizontal dampers keep weight low and response sharp." },
      { x: 68, y: 28, dx: 70, dy: -25, hl: 220, l: "Carbon tub", b: "A single carbon-fibre shell, light and absurdly stiff." }]
    },
    {
      n: "Craft", a: [301, 367], c: "#E8C39A", h: "MADE BY HAND", hp: { al: "l", x: 30, y: 7 },
      t: "Craft", d: "Hundreds of hands and thousands of hours. In Sant'Agata Bolognese, each car is assembled, never just manufactured.",
      co: [{ x: 50, y: 64, dx: 90, dy: 75, hl: 250, l: "Born in Sant'Agata", b: "Founded in 1963 by Ferruccio Lamborghini, a tractor maker with a point to prove." },
      { x: 28, y: 50, dx: -55, dy: -85, hl: 230, l: "Hand-laid carbon", b: "Every ply is positioned by a person before it meets the oven." }]
    },
    {
      n: "Scissor Doors", a: [368, 430], c: "#BFE6FF", h: "UP, NOT OUT", hp: { al: "r", x: 4, y: 76 },
      t: "Scissor Doors", d: "Since the Countach in 1974, Lamborghini doors do not open, they rise. It is theatre, and it is engineered.",
      co: [{ x: 33, y: 30, dx: -85, dy: -60, hl: 230, l: "One vertical hinge", b: "A single pivot swings the door up and forward." },
      { x: 71, y: 30, dx: 90, dy: -70, hl: 230, l: "Countach heritage", b: "The first production scissor doors, 1974. Still the best entrance." }]
    },
    {
      n: "V12 Voice", a: [431, 500], c: "#3EE6FF", h: "THUNDER ON DEMAND", hp: { al: "l", x: 5, y: 10 },
      t: "V12 Voice", d: "At idle, a growl. At full throttle, a cathedral organ made of fire. Three tailpipes glow cyan as it exhales.",
      co: [{ x: 50, y: 63, dx: 90, dy: 80, hl: 250, l: "Triple tailpipes", b: "Heat-glowing and tuned for a note you will remember." },
      { x: 80, y: 55, dx: 50, dy: -70, hl: 200, l: "The V12 heritage", b: "Twelve cylinders, a high-revving scream and no turbo to muffle it." }]
    },
    {
      n: "Get it today", a: [501, 547], c: "#FFC72C", h: "GET IT TODAY", hp: { al: "c", y: 36 }, late: true, play: .72, cta: true,
      t: "The Last Light", d: "Smoke swallows the tail lights. The road ahead is yours. Pick a bull and make it yours.", co: []
    }
  ];

  /* MOBILE 9:16: phones show a portrait crop of the 16:9 frame (no more letterbox).
     For each section the crop follows its first callout: fo.x = where it is in the frame (0-1),
     fo.s = where on the phone screen we want it (left side if its label goes right, and vice versa). */
  S.forEach(s => { const c = s.co[0]; s.fo = c ? { x: c.x / 100, s: c.dx >= 0 ? .28 : .72 } : { x: .5, s: .5 }; });
  let focus = S[0].fo, X0 = 0;      // X0 = left edge of the crop, as a fraction of the frame width
  const panTarget = () => { const w = W / H / AR; return Math.min(1 - w, Math.max(0, focus.x - focus.s * w)); };

  /* ---------- state / elements ---------- */
  const stage = $("#stage"), track = $("#track"), cv = $("#cv"), ctx = cv.getContext("2d", { alpha: false }),
    fxc = $("#fx"), fx = fxc.getContext("2d"), layersEl = $("#layers");
  let W, H, DPR = 1, FDPR = 1, offs = [], hs = [], total = 0, curF = 0, tgtF = 0, lastY = -1, curI = -1;
  const mouse = { x: -9999, y: -9999 };
  let ready = false, fontOK = false;

  /* ---------- build layers ---------- */
  /* ---------- 2. LAYERS: one <section class="layer"> per story section (title + callouts + text) ---------- */
  // pos(): turns the "hp" placement of a title into CSS (c = centred, l = left, r = right; x/y in vw/vh)
  const pos = p => p.al === "c" ? `left:0;right:0;text-align:center;top:${p.y}vh` :
    p.al === "l" ? `left:${p.x}vw;top:${p.y}vh;text-align:left` :
      `right:${p.x}vw;top:${p.y}vh;text-align:right`;
  // callout(): the dot + line + label that points at a part of the car (j=1 means secondary: hidden on phones)
  function callout(c, j) {
    const sx = c.dx >= 0 ? 1 : -1, ex = c.dx, ey = c.dy, fxx = ex + sx * c.hl;
    const left = sx > 0 ? ex : ex - c.hl;
    return `<div class="co${j ? " sec" : ""}" data-x="${c.x}" style="left:${c.x}%;top:${c.y}%"><i class="dot"></i>
   <svg width="1" height="1"><path pathLength="1" d="M0 0L${ex} ${ey}L${fxx} ${ey}"/></svg>
   <div class="ct" style="left:${left}px;top:${ey}px;width:${c.hl}px;text-align:${sx > 0 ? "left" : "right"}">
    <h4>${c.l}</h4><p>${c.b}</p></div></div>`;
  }
  S.forEach((s, i) => {
    const L = document.createElement("section");
    L.className = "layer"; L.style.setProperty("--c", s.c); L.setAttribute("aria-label", s.n);
    L.innerHTML = `<h2 class="head${s.late ? " late" : ""}${HEAD_FX ? " pfx" : ""}" data-fx="#ffffff" style="${pos(s.hp)}">${s.h}</h2>` +
      s.co.map(callout).join("") +
      `<div class="bl" ${s.late ? 'data-he="1"' : ""}><h3${TITLE_FX ? ' class="pfx" data-fx="c"' : ""}>${s.t}</h3><p>${s.d}</p></div>` +
      (s.cta ? `<a class="cta" href="#configurator" data-go="#configurator">Build yours</a>` : "");
    layersEl.appendChild(L); s.el = L;
  });

  const cos = $$(".co").map(el => ({ el, x: +el.dataset.x }));
  // placeCo(): on phones, slides the callout dots along with the cropped frame so they stay on the right part of the car
  function placeCo() {
    const w = W / H / AR, port = W / H < 1;
    cos.forEach(c => { c.el.style.left = port ? ((c.x / 100 - X0) / w * 100) + "%" : c.x + "%"; });
  }

  /* ---------- ticks (the little vertical bars top-right that jump between story chapters) ---------- */
  const tk = $("#tk"), tl = $("#tl");
  S.forEach((s, i) => {
    const b = document.createElement("button");
    b.className = "tick"; b.type = "button"; b.setAttribute("aria-label", `Go to ${s.n}`);
    b.innerHTML = "<i></i>"; s.tick = b;
    b.addEventListener("click", () => glide(offs[i] + hs[i] * .14 + 2));
    b.addEventListener("mouseenter", () => { tl.textContent = s.n; tl.style.color = s.c; });
    b.addEventListener("mouseleave", () => { tl.textContent = S[Math.max(0, curI)].n; tl.style.color = S[Math.max(0, curI)].c; });
    tk.appendChild(b);
  });

  /* ---------- smooth glide (ticks + links) ---------- */
  let gid = 0;
  function glide(to) {
    cancelAnimationFrame(gid);
    const from = scrollY, d = to - from, t0 = performance.now(),
      dur = Math.min(2800, Math.max(900, Math.abs(d) / H * 240)),
      ease = x => x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2;
    (function step(n) {
      const k = Math.min(1, (n - t0) / dur);
      scrollTo(0, from + d * ease(k));
      if (k < 1) gid = requestAnimationFrame(step);
    })(t0);
  }
  ["wheel", "touchstart", "keydown"].forEach(e => addEventListener(e, () => cancelAnimationFrame(gid), { passive: true }));

  /* ---------- 3. PAGE WIPE (pagination transition between the 3 pages) ----------
     Page 1 = the story animation, page 2 = Choose your bull, page 3 = Contact.
     Whenever you move between pages (scrolling, buttons, the 01/02/03 pager) 5 dark bars sweep over
     the screen, show the page name, then sweep away. HTML is #pt, CSS is "page wipe" in style.css. */
  const PG = ["The Story", "Choose your bull", "Make it yours"];   // names shown in the wipe (edit freely)
  const pt = $("#pt"), pgBtns = $$("#pg button");
  let ptBusy = false, curPg = 0;
  // pageOf(y): which page is a scroll position in? (the next page counts once 20% of it is visible)
  const pageOf = y => y > $("#contact").offsetTop - H * .8 ? 2 : y > $("#configurator").offsetTop - H * .8 ? 1 : 0;
  const pageTop = i => i === 0 ? 0 : $(i === 1 ? "#configurator" : "#contact").offsetTop;
  function setPg(i) { curPg = i; pgBtns.forEach((b, k) => b.classList.toggle("act", k === i)); }
  // wipe(i, jump): play the bars; jump() (optional) runs while the screen is fully covered
  function wipe(i, jump) {
    $("small", pt).textContent = `0${i + 1} / 03`; $("b", pt).textContent = PG[i];
    if (reduce || ptBusy) { if (jump) jump(); return; }          // reduced motion or already wiping: just go
    ptBusy = true; pt.className = "in";
    setTimeout(() => { if (jump) jump(); pt.className = "out"; setTimeout(() => { pt.className = ""; ptBusy = false; }, 700); }, 760);
  }
  // goTo(y): go to scroll position y. Another page -> wipe + instant jump. Same page -> smooth glide.
  function goTo(y) { const i = pageOf(y); if (i === curPg) return glide(y); setPg(i); wipe(i, () => scrollTo(0, y)); }
  $("#pg").addEventListener("click", e => { const b = e.target.closest("[data-pg]"); if (b) goTo(pageTop(+b.dataset.pg)); });
  // any element with data-go="#id" (e.g. the "Build yours" button) navigates with goTo
  document.addEventListener("click", e => {
    const a = e.target.closest("[data-go]"); if (!a) return;
    e.preventDefault(); const t = $(a.dataset.go); if (t) goTo(t.getBoundingClientRect().top + scrollY);
  });

  /* ---------- frame loader (first ~160 frames first, rest in background, demand-aware) ---------- */
  /* ---------- 4. FRAME LOADER ----------
     Frames needed soonest (around the current scroll) load first, the rest load quietly in the background. */
  const imgs = new Array(N), ok = new Uint8Array(N), busy = new Uint8Array(N);
  let loaded = 0, inflight = 0, ptr = 0;
  const bar = $("#ld .bar i");
  function pick() {
    const c = Math.round(curF);
    for (let k = 0; k < 48; k++) { const i = c + k; if (i < N && !ok[i] && !busy[i]) return i; }
    while (ptr < N && (ok[ptr] || busy[ptr])) ptr++;
    return ptr < N ? ptr : -1;
  }
  function pump() {
    const max = loaded < 160 ? 8 : 4;
    while (inflight < max) { const i = pick(); if (i < 0) return; load(i); }
  }
  function load(i) {
    busy[i] = 1; inflight++;
    const im = new Image(); im.decoding = "async";
    im.onload = im.onerror = () => {
      if (im.naturalWidth) { ok[i] = 1; imgs[i] = im; }
      loaded++; inflight--;
      bar.style.width = Math.min(100, loaded / 24 * 100) + "%";
      if (!ready && ok[0] && loaded >= 24) start();
      pump();
    };
    im.src = FR(i);
  }
  function nearest(f) {
    f = Math.round(f);
    for (let d = 0; d < 80; d++) { if (f - d >= 0 && ok[f - d]) return imgs[f - d]; }
    for (let d = 1; d < N; d++) { if (f + d < N && ok[f + d]) return imgs[f + d]; }
    return null;
  }
  let drawnF = -1, needDraw = true;
  // drawFrame(): paints the current frame on the canvas (only when the frame or the crop changed)
  function drawFrame() {
    const f = Math.round(curF);
    if (f === drawnF && !needDraw) return;
    const im = nearest(f); if (!im) return;
    drawnF = f; needDraw = false;
    const cw = cv.width, ch = cv.height, iw = im.naturalWidth, ih = im.naturalHeight,
      sc = Math.max(cw / iw, ch / ih), dw = iw * sc, dh = ih * sc;      // "cover" scaling: the frame always fills the screen
    // portrait phones: show a 9:16 slice of the frame, positioned by X0 (see MOBILE 9:16 above); otherwise centre it
    const dx = cw / ch < 1 ? -X0 * dw : (cw - dw) / 2;
    ctx.drawImage(im, dx, (ch - dh) / 2, dw, dh);
  }

  /* ---------- layout ---------- */
  /* ---------- layout: runs at start and on resize; sizes canvases and the scroll track ---------- */
  function layout() {
    W = stage.clientWidth; H = stage.clientHeight;
    DPR = Math.min(devicePixelRatio || 1, 1.5); FDPR = Math.min(devicePixelRatio || 1, 2);
    cv.width = W * DPR; cv.height = H * DPR; fxc.width = W * FDPR; fxc.height = H * FDPR;
    fx.setTransform(FDPR, 0, 0, FDPR, 0, 0);
    offs = []; hs = []; total = 0;
    S.forEach(s => { const h = (.7 + (s.a[1] - s.a[0] + 1) * .0105) * H; offs.push(total); hs.push(h); total += h; });
    track.style.height = (total + H) + "px";
    X0 = panTarget(); placeCo();
    needDraw = true;
    if (fontOK) { fxEls.forEach(f => { f.parts = null; }); buildQueue = fxEls.slice(); }
  }

  /* ---------- particle text ---------- */
  /* ---------- 5. PARTICLE TITLES ----------
     Only elements with class "pfx" (the bottom primary chapter title) become particles. Each particle flies from a random
     spot to its place in the letters, floats a little, and runs away from the mouse/finger. */
  const fxEls = $$(".pfx").map(el => {
    const L = el.closest(".layer"), i = +S.findIndex(s => s.el === L);
    return {
      el, i, late: el.classList.contains("late"), grad: el.classList.contains("head"), he: !!(el.closest(".bl") && el.closest(".bl").dataset.he), alpha: 0, act: false, t0: 0, parts: null,
      col: el.dataset.fx === "c" ? S[i].c : el.dataset.fx, acc: S[i].c, mix: parseFloat(el.dataset.mix || 0)
    };
  });
  let buildQueue = [];
  // build(f): draws the title text on a hidden canvas, then turns every visible pixel (on a grid) into a particle
  function build(f) {
    const el = f.el, cs = getComputedStyle(el), r = el.getBoundingClientRect(), sr = stage.getBoundingClientRect();
    const w = Math.ceil(r.width), h = Math.ceil(r.height); if (!w || !h) { f.parts = []; return; }
    f.ox = r.left - sr.left; f.oy = r.top - sr.top;
    const fs = parseFloat(cs.fontSize), lh = parseFloat(cs.lineHeight) || fs * 1.25;
    const o = document.createElement("canvas"); o.width = w; o.height = h;
    const c = o.getContext("2d", { willReadFrequently: true });
    c.font = `${fs}px Sakana`; c.textBaseline = "top"; c.fillStyle = "#fff";
    if ("letterSpacing" in c && cs.letterSpacing !== "normal") c.letterSpacing = cs.letterSpacing;
    const right = cs.textAlign === "right" || cs.textAlign === "end", ctr = cs.textAlign === "center";
    c.textAlign = right ? "right" : ctr ? "center" : "left";
    const lines = []; let line = "";
    el.textContent.trim().split(/\s+/).forEach(wd => {
      const t = line ? line + " " + wd : wd;
      if (c.measureText(t).width > w && line) { lines.push(line); line = wd; } else line = t;
    });
    lines.push(line);
    lines.forEach((ln, k) => c.fillText(ln, right ? w : ctr ? w / 2 : 0, k * lh + (lh - fs) / 2));
    const small = W < 700, d = c.getImageData(0, 0, w, h).data,
      g = fs >= 90 ? 4 : fs >= 40 ? 3 : fs >= 22 ? 2 : (small ? 2 : 1), sz = g === 4 ? 3.4 : g === 1 ? 1.4 : g === 2 ? 1.9 : 2.6, keep = g === 1 ? .78 : 1, parts = [];
    for (let y = 0; y < h; y += g) for (let x = 0; x < w; x += g) {
      if (d[(y * w + x) * 4 + 3] > 110 && Math.random() < keep) {
        const m = f.grad ? Math.random() < Math.max(0, (x / w - .3) / .7) : Math.random() < f.mix;   // titles fade white -> accent colour left to right
        parts.push({
          hx: x, hy: y, sx: x + (Math.random() - .5) * 260, sy: y + (Math.random() - .3) * 200 - 40, x: 0, y: 0, vx: 0, vy: 0,
          d: (x / w) * .45 + Math.random() * .35, o: .55 + Math.random() * .45, ph: Math.random() * 6.28, c: m ? 1 : 0, sz
        });
      }
    }
    parts.sort((a, b) => a.c - b.c);
    f.parts = parts; f.cols = [f.col, f.acc]; f.w = w;
    parts.forEach(p => { p.x = p.sx; p.y = p.sy; });
  }
  function idleBuild(dl) {
    while (buildQueue.length && (dl.timeRemaining ? dl.timeRemaining() > 4 : true)) { const f = buildQueue.shift(); if (!f.parts) build(f); }
    if (buildQueue.length) schedule();
  }
  function schedule() { (window.requestIdleCallback || (cb => setTimeout(() => cb({ timeRemaining: () => 8 }), 30)))(idleBuild); }
  function setAct(f, on, now) {
    if (f.act === on) return;
    f.act = on;
    if (on) {
      if (!f.parts) build(f);
      f.t0 = now;
      if (f.alpha < .05 && f.parts) f.parts.forEach(p => { p.x = p.sx; p.y = p.sy; p.vx = p.vy = 0; });
    }
  }
  // drawFx(): moves + paints all particles every frame (springs toward their spot, pushed away by the pointer)
  function drawFx(now) {
    fx.clearRect(0, 0, W, H);
    const R = 85, R2 = R * R;
    for (const f of fxEls) {
      if (!f.parts) continue;
      f.alpha += ((f.act ? 1 : 0) - f.alpha) * (f.act ? .09 : .14);
      if (f.alpha < .012 && !f.act) continue;
      const age = (now - f.t0) / 1000, ox = f.ox, oy = f.oy, t = now * .0015;
      let lc = -1;
      for (const p of f.parts) {
        let tx, ty;
        if (f.act) { if (age < p.d) continue; tx = p.hx; ty = p.hy; } else { tx = p.sx; ty = p.sy; }
        p.vx += (tx - p.x) * .07; p.vy += (ty - p.y) * .07;
        const mx = p.x + ox - mouse.x, my = p.y + oy - mouse.y, d2 = mx * mx + my * my;
        if (d2 < R2) { const dd = Math.sqrt(d2) || 1, k = (1 - d2 / R2) * 3.2; p.vx += mx / dd * k; p.vy += my / dd * k; }
        p.vx *= .82; p.vy *= .82; p.x += p.vx; p.y += p.vy;
        if (p.c !== lc) { fx.fillStyle = f.cols[p.c]; lc = p.c; }
        fx.globalAlpha = f.alpha * p.o;
        fx.fillRect(ox + p.x + Math.sin(t + p.ph) * .45, oy + p.y + Math.cos(t * 1.1 + p.ph) * .45, p.sz, p.sz);
      }
    }
    fx.globalAlpha = 1;
  }
  addEventListener("pointermove", e => { const r = stage.getBoundingClientRect(); mouse.x = e.clientX - r.left; mouse.y = e.clientY - r.top; }, { passive: true });
  addEventListener("pointerleave", () => { mouse.x = mouse.y = -9999; });

  /* ---------- scroll -> section / frame ---------- */
  /* ---------- 6. SCROLL ENGINE ----------
     update(): from the scroll position finds the active story section, the target frame, the accent colour,
     and switches the matching layer + particle title on/off. */
  function update(y, now) {
    let i = S.length - 1; while (i > 0 && y < offs[i]) i--;
    const s = S[i], t = (y - offs[i]) / hs[i];
    const p = Math.min(1, Math.max(0, t / (s.play || 1)));
    focus = s.fo;                       // phones: where the 9:16 crop should look
    tgtF = s.a[0] + (s.a[1] - s.a[0]) * p;
    const last = i === S.length - 1, end = last && t > (s.play || 1) + .02;
    S.forEach((q, k) => {
      const on = k === i && (k === 0 ? t < .97 : (t > .02 && (last || t < .97)));
      const wasOn = q.el.classList.contains("on");
      if (on !== wasOn) q.el.classList.toggle("on", on);
      q.el.classList.toggle("end", on && end && k === i);
      fxEls.forEach(f => { if (f.i === k) setAct(f, ready && on && !(f.he && end) && (!f.late || end), now); });   // "GET IT TODAY" title only appears at the very end
    });
    if (i !== curI) {
      curI = i; S.forEach((q, k) => q.tick.classList.toggle("act", k === i));
      document.documentElement.style.setProperty("--c", s.c); tl.textContent = s.n; tl.style.color = s.c;
    }
    $("#ticks").classList.toggle("hide", y > total + H * .5);
    $("#cue").classList.toggle("gone", y > 40);
  }
  // frame(): the main loop, runs every screen refresh (smooths the frame number, draws the frame, draws the particles)
  function frame(now) {
    const y = scrollY;
    if (ready) {
      const pg = pageOf(y); if (pg !== curPg) { setPg(pg); wipe(pg); }      // natural scrolling into another page -> play the wipe
      if (W / H < 1) { const t = panTarget(); if (Math.abs(t - X0) > .0003) { X0 += (t - X0) * .08; needDraw = true; placeCo(); } }  // glide the phone crop
      update(y, now); curF += (tgtF - curF) * .14; if (Math.abs(tgtF - curF) < .02) curF = tgtF; drawFrame();
    }
    if (ready && y < total + H) drawFx(now); else if (ready) fx.clearRect(0, 0, W, H);
    requestAnimationFrame(frame);
  }
  // start(): hides the loader once the first frames are in
  function start() {
    ready = true;
    $("#ld").classList.add("done");
    document.body.style.overflow = "";
  }
  // keep first-frame loader snappy: reveal after ~2.2s even if still fetching frame 24
  setTimeout(() => { if (!ready && ok[0]) start(); }, 2200);

  /* ---------- init (runs once) ---------- */
  setPg(0);
  layout();
  addEventListener("resize", () => { clearTimeout(layout.t); layout.t = setTimeout(layout, 150); });
  document.body.style.overflow = "hidden";
  if (history.scrollRestoration) history.scrollRestoration = "manual";
  scrollTo(0, 0);
  pump();
  requestAnimationFrame(frame);
  (document.fonts ? document.fonts.load("20px Sakana") : Promise.resolve()).then(() => document.fonts && document.fonts.ready).catch(() => { }).then(() => {
    fontOK = true; buildQueue = fxEls.slice(); schedule();
  });

  /* ---------- 7. COLLECTION + CONFIGURATOR ("Choose your bull") ----------
     CARS = the 4 models. k = file prefix of that car's recoloured pictures: img/v/<k>-<finish number>.webp
     (4 cars x 6 finishes = 24 pictures, made once from the photos in img/). Add a car: add an entry here + its 6 images. */
  const CARS = [
    { n: "Sián FKP 37", tag: "Hybrid V12 hypercar", k: "sian", img: "img/sian.webp", d: "A V12 paired with a supercapacitor, built in a tiny run. Matte green and bronze wheels are its signature." },
    { n: "Urus", tag: "Super SUV", k: "urus", img: "img/urus.webp", d: "Five seats, twin-turbo V8 and the manners of a supercar. Proof that practical can still be loud." },
    { n: "Revuelto SV", tag: "Plug-in hybrid V12", k: "revuelto", img: "img/revuelto.webp", d: "The V12 flagship sharpened for the track, with winglets, carbon and a very red attitude." },
    { n: "Aventador Ultimae Roadster", tag: "Final V12 roadster", k: "aventador", img: "img/aventador.webp", d: "The last Aventador, open to the sky. A naturally aspirated V12 sending its farewell skyward." }
  ];
  // FIN = [finish name, colour of the swatch]  (order = number in the picture file names: sian-0, sian-1 ...)
  const FIN = [["Verde Mantis", "#8fb23c"], ["Giallo Orion", "#ffcf1f"], ["Arancio Xanto", "#ff6a1a"], ["Rosso Mars", "#d3212d"], ["Nero Noctis", "#0b0b0d"], ["Bianco Monocerus", "#ecebe6"]];
  // WH = wheel options, INT = interior options (their pictures are drawn by wheelSVG / intSVG below)
  const WH = ["Forged bronze", "Gloss black", "Diamond-cut silver"], INT = ["Nero Ade leather", "Marrone Elpis", "Rosso Alala"];
  // st = what the visitor has picked so far (indexes into the lists above) + which configurator page they are on
  const st = { car: 0, fin: 0, wh: 0, int: 0, step: 0 };
  const STEPS = ["Model", "Finish", "Wheels and interior", "Review"];
  // colours for the generated wheel + interior drawings: [main colour, shade/stitch colour]
  const WHC = [["#c98a4b", "#6b3f1d"], ["#2a2a30", "#0e0e11"], ["#e4e6ea", "#8a8d96"]], INC = [["#1a1a1e", "#ffc72c"], ["#6e4126", "#ead6b4"], ["#a8222f", "#1b1b1b"]];
  // wheelSVG(i): draws a 10-spoke forged wheel (tyre, spokes, hub, red caliper) in the colours of option i
  const wheelSVG = i => {
    const [a, b] = WHC[i]; let sp = "";
    for (let k = 0; k < 10; k++) sp += `<path transform="rotate(${k * 36})" d="M-5 -14L-9 -42L9 -42L5 -14Z" fill="url(#wg${i})"/>`;
    return `<svg viewBox="-60 -60 120 120" role="img" aria-label="${WH[i]} wheel"><defs><radialGradient id="wg${i}"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></radialGradient></defs><circle r="58" fill="#0c0c0e"/><circle r="47" fill="#050506"/>${sp}<circle r="46" fill="none" stroke="${a}" stroke-width="3"/><circle r="13" fill="url(#wg${i})"/><circle r="4.5" fill="#111"/><path d="M18 -40A44 44 0 0 1 40 -18L31 -14A33 33 0 0 0 14 -31Z" fill="#ff3b30"/></svg>`;
  };
  // intSVG(i): draws a diamond-stitched seat in the leather colour + stitching colour of option i
  const intSVG = i => {
    const [a, t] = INC[i], seat = "M30 12Q60 2 90 12L98 74Q60 84 22 74Z";
    return `<svg viewBox="0 0 120 120" role="img" aria-label="${INT[i]} interior"><defs><pattern id="ip${i}" width="12" height="12" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0H12M0 0V12" stroke="${t}" stroke-width=".9" opacity=".85"/></pattern><linearGradient id="il${i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".12"/><stop offset="1" stop-color="#000" stop-opacity=".55"/></linearGradient></defs><path d="${seat}" fill="${a}"/><path d="${seat}" fill="url(#ip${i})"/><path d="${seat}" fill="url(#il${i})"/><path d="M18 80Q60 92 102 80L106 108Q60 118 14 108Z" fill="${a}" stroke="${t}" stroke-width="1.6" stroke-dasharray="3 2"/></svg>`;
  };
  let lastCar = -1;
  const esc = s => s.replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const summary = () => `${CARS[st.car].n}, ${FIN[st.fin][0]}, ${WH[st.wh]} wheels, ${INT[st.int]} interior`;

  $("#cars").innerHTML = CARS.map((c, i) => `<article class="car glass" data-i="${i}"><div class="im"><img src="${c.img}" alt="${esc(c.n)}" loading="lazy" decoding="async"></div>
 <div class="cb"><h3>${c.n}</h3><p class="tg">${c.tag}</p><p class="ds">${c.d}</p>
 <div class="bt"><button class="b pri" data-act="cfg" type="button">Configure</button><button class="b" data-act="drive" type="button">Book a drive</button></div></div></article>`).join("");
  $("#fmodel").innerHTML = CARS.map((c, i) => `<option value="${esc(c.n)}">${c.n}</option>`).join("");

  // render(): redraws everything that depends on st (preview picture, wheel/interior drawings, option buttons, pager, summary)
  function render() {
    const c = CARS[st.car];
    document.documentElement.style.setProperty("--g", FIN[st.fin][1] === "#0b0b0d" ? "#59595f" : FIN[st.fin][1]);
    $$(".car").forEach((e, i) => e.classList.toggle("sel", i === st.car));
    // main picture = this car in the chosen finish; fades out, swaps, fades in
    const im = $("#pvimg"), src = `img/v/${c.k}-${st.fin}.webp`;
    if (im.getAttribute("src") !== src) { im.style.opacity = 0; setTimeout(() => { im.src = src; im.alt = `${c.n} in ${FIN[st.fin][0]}`; im.style.opacity = 1; }, 220); }
    if (st.car !== lastCar) { lastCar = st.car; FIN.forEach((_, i) => { new Image().src = `img/v/${c.k}-${i}.webp`; }); }   // preload the other finishes so switching is instant
    // wheel + interior "chips": redrawn (with a little pop animation) only when their choice changed
    const chip = (id, key, svg, label) => { const e = $(id); if (e.dataset.k === key) return; e.dataset.k = key; e.innerHTML = svg + `<figcaption>${label}</figcaption>`; e.classList.remove("pop"); void e.offsetWidth; e.classList.add("pop"); };
    chip("#chw", "w" + st.wh, wheelSVG(st.wh), WH[st.wh]); chip("#chi", "i" + st.int, intSVG(st.int), INT[st.int]);
    $("#pvname").textContent = c.n; $("#pvtag").textContent = `${FIN[st.fin][0]}  |  ${WH[st.wh]}  |  ${INT[st.int]}`;
    $("#sn").textContent = `Page ${st.step + 1} of ${STEPS.length}`; $("#st").textContent = STEPS[st.step];
    const opt = (k, v, label, on, extra = "") => `<button class="opt${on ? " on" : ""}" data-k="${k}" data-v="${v}" type="button">${extra}${label}</button>`;
    let b = "";
    if (st.step === 0) b = `<div class="opts">${CARS.map((x, i) => opt("car", i, x.n, i === st.car)).join("")}</div>`;
    if (st.step === 1) b = `<div class="sw">${FIN.map((f, i) => opt("fin", i, f[0], i === st.fin, `<s style="background:${f[1]}"></s>`)).join("")}</div>`;
    if (st.step === 2) b = `<div class="grp"><span>Wheels</span><div class="opts">${WH.map((x, i) => opt("wh", i, x, i === st.wh)).join("")}</div></div>
    <div class="grp"><span>Interior</span><div class="opts">${INT.map((x, i) => opt("int", i, x, i === st.int)).join("")}</div></div>`;
    if (st.step === 3) b = `<div class="sum"><div><span>Model</span>${c.n}</div><div><span>Finish</span>${FIN[st.fin][0]}</div><div><span>Wheels</span>${WH[st.wh]}</div><div><span>Interior</span>${INT[st.int]}</div></div>`;
    $("#sb").innerHTML = b;
    $("#pd").innerHTML = STEPS.map((s, i) => `<button type="button" data-p="${i}" class="${i === st.step ? "on" : ""}" aria-label="${s}" ${i === st.step ? 'aria-current="step"' : ""}>${i + 1}</button>`).join("");
    $("#pp").disabled = st.step === 0; $("#pnx").textContent = st.step === 3 ? "Send my build" : "Next";
    $("#chip").textContent = summary(); $("#fmodel").value = c.n;
  }
  // clicks: option buttons change st, pager dots / Back / Next change the configurator page, car cards pick a model
  $("#sb").addEventListener("click", e => { const b = e.target.closest("[data-k]"); if (!b) return; st[b.dataset.k] = +b.dataset.v; render(); });
  $("#pd").addEventListener("click", e => { const b = e.target.closest("[data-p]"); if (b) { st.step = +b.dataset.p; render(); } });
  $("#pp").addEventListener("click", () => { st.step = Math.max(0, st.step - 1); render(); });
  $("#pnx").addEventListener("click", () => {
    if (st.step < 3) { st.step++; render(); return; }
    $("#fmsg").value = `I would like to build: ${summary()}.`; goTo($("#contact").getBoundingClientRect().top + scrollY);
  });
  $("#cars").addEventListener("click", e => {
    const b = e.target.closest("[data-act]"), card = e.target.closest(".car"); if (!b) return;
    st.car = +card.dataset.i;
    if (b.dataset.act === "cfg") { st.step = 1; render(); goTo($("#cfg").getBoundingClientRect().top + scrollY - H * .12); }
    else { render(); $("#fmsg").value = `I would like to book a drive in the ${CARS[st.car].n}.`; goTo($("#contact").getBoundingClientRect().top + scrollY); }
  });
  $("#fmodel").addEventListener("change", e => { const i = CARS.findIndex(c => c.n === e.target.value); if (i > -1) { st.car = i; render(); } });
  render();

  /* ---------- 8. CONTACT FORM ----------
     On Netlify the form is captured automatically (data-netlify in index.html). Anywhere else the POST fails and we fall back
     to opening the visitor's mail app addressed to CONTACT_EMAIL (top of this file) with the whole build filled in. */
  const form = $("#form");
  form.addEventListener("submit", async e => {
    e.preventDefault();
    const fd = new FormData(form); fd.set("build", summary());
    let sent = false;
    try { const r = await fetch("/", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: new URLSearchParams(fd) }); sent = r.ok; } catch (_) { }
    if (!sent) {
      const body = `${fd.get("message") || ""}\n\nBuild: ${summary()}\nName: ${fd.get("name")}\nEmail: ${fd.get("email")}\nPhone: ${fd.get("phone") || ""}`;
      location.href = `mailto:${CONTACT_EMAIL}?subject=${encodeURIComponent("My build: " + CARS[st.car].n)}&body=${encodeURIComponent(body)}`;
      $("#okp").textContent = "Your email app should open with the build filled in. Just press send.";
    }
    form.classList.add("sent");
  });
})();
